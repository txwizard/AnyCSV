﻿/*****************************************************/
/***    Copyright (c) 2014 Vladimir Nikitenko      ***/
/***      Code Project Open License (CPOL)         ***/
/*** (http://www.codeproject.com/info/cpol10.aspx) ***/
/*****************************************************/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using Nvv.IO.CSV.Cs;

namespace CSVReaderTest_WinForms
{
    public partial class Form1 : Form
    {
        private CSVReader _CurrentCSVReader;
        private string _InitialDirectory;
        private DataTable _DataTable;


        private bool FieldCount_AutoDetect 
        { 
            get { return _CurrentCSVReader.FieldCount_AutoDetect; }
            set 
            {
                try
                {
                    if (_CurrentCSVReader.FieldCount_AutoDetect != value)
                        _CurrentCSVReader.FieldCount_AutoDetect = value;
                }
                //do not catch here. Application.ThreadException in Program.cs will be sufficient
                finally
                {
                    checkBox_FieldCount_AutoDetect.Checked = FieldCount_AutoDetect;
                    textBox_FieldCount.Enabled = ! FieldCount_AutoDetect;
                    labelFieldCountCaption.Enabled = !FieldCount_AutoDetect;
                }
            }
        }// FieldCount_AutoDetect

        private void checkBox_FieldCount_AutoDetect_CheckedChanged(object sender, EventArgs e)
        {
            FieldCount_AutoDetect = checkBox_FieldCount_AutoDetect.Checked;
        }

        private string FieldCount
        {
            get { return _CurrentCSVReader.FieldCount.ToString(); }
            set
            {
                try
                {
                    int intValue = Convert.ToInt32(value);
                    if (_CurrentCSVReader.FieldCount != intValue)
                        _CurrentCSVReader.FieldCount = intValue;
                }
                finally
                {
                    textBox_FieldCount.Text = FieldCount;
                }
            }
        }// FieldCount

        private void textBox_FieldCount_Leave(object sender, EventArgs e)
        {
            FieldCount = textBox_FieldCount.Text;
        }

        private bool HeaderPresent
        {
            get { return _CurrentCSVReader.HeaderPresent; }
            set
            {
                try
                {
                    if (_CurrentCSVReader.HeaderPresent != value)
                        _CurrentCSVReader.HeaderPresent = value;
                }
                finally
                {
                    checkBox_HeaderPresent.Checked = HeaderPresent;
                }
            }
        }// HeaderPresent

        private void checkBox_HeaderPresent_CheckedChanged(object sender, EventArgs e)
        {
            HeaderPresent = checkBox_HeaderPresent.Checked;
        }

        private bool UseFieldDblQuoting
        {
            get { return _CurrentCSVReader.UseFieldQuoting; }
            set
            {
                try
                {
                    if (_CurrentCSVReader.UseFieldQuoting != value)
                        _CurrentCSVReader.UseFieldQuoting = value;
                }
                finally
                {
                    checkBox_UseFieldDblQuoting.Checked = UseFieldDblQuoting;
                }
            }
        }// UseFieldQuoting

        private void checkBox_UseFieldDblQuoting_CheckedChanged(object sender, EventArgs e)
        {
            UseFieldDblQuoting = checkBox_UseFieldDblQuoting.Checked;
        }

        private bool IgnoreEmptyLines
        {
            get { return _CurrentCSVReader.IgnoreEmptyLines; }
            set
            {
                try
                {
                    if (_CurrentCSVReader.IgnoreEmptyLines != value)
                        _CurrentCSVReader.IgnoreEmptyLines = value;
                }
                finally
                {
                    checkBox_IgnoreEmptyLines.Checked = IgnoreEmptyLines;
                }
            }
        }// IgnoreEmptyLines

        private void checkBox_IgnoreEmptyLines_CheckedChanged(object sender, EventArgs e)
        {
            IgnoreEmptyLines = checkBox_IgnoreEmptyLines.Checked;
        }

        private bool IgnoreSpecialCharacters
        {
            get { return _CurrentCSVReader.IgnoreSpecialCharacters; }
            set
            {
                try
                {
                    if (_CurrentCSVReader.IgnoreSpecialCharacters != value)
                        _CurrentCSVReader.IgnoreSpecialCharacters = value;
                }
                finally
                {
                    checkBox_IgnoreSpecialCharacters.Checked = IgnoreSpecialCharacters;
                }
            }
        }// IgnoreSpecialCharacters

        private void checkBox_IgnoreSpecialCharacters_CheckedChanged(object sender, EventArgs e)
        {
            IgnoreSpecialCharacters = checkBox_IgnoreSpecialCharacters.Checked;
        }

        private string FieldSeparatorCharCode
        {
            get { return "0x" + _CurrentCSVReader.FieldSeparatorCharCode.ToString("X4"); }
            set
            {
                try
                {
                    int intValue = Hex0x4DigitMaxStringToUInt(value);
                    if (_CurrentCSVReader.FieldSeparatorCharCode != intValue)
                        _CurrentCSVReader.FieldSeparatorCharCode = intValue;
                }
                finally
                {
                    textBox_FieldSeparatorCharCode.Text = FieldSeparatorCharCode;
                }
            }
        }// FieldSeparatorCharCode

        private void textBox_FieldSeparatorCharCode_Leave(object sender, EventArgs e)
        {
            FieldSeparatorCharCode = textBox_FieldSeparatorCharCode.Text;
        }

        private string QuoteCharCode
        {
            get { return "0x" + _CurrentCSVReader.QuoteCharCode.ToString("X4"); }
            set
            {
                try
                {
                    int intValue = Hex0x4DigitMaxStringToUInt(value);
                    if (_CurrentCSVReader.QuoteCharCode != intValue)
                        _CurrentCSVReader.QuoteCharCode = intValue;
                }
                finally
                {
                    textBox_QuoteCharCode.Text = QuoteCharCode;
                }
            }
        }// QuoteCharCode

        private void textBox_QuoteCharCode_Leave(object sender, EventArgs e)
        {
            QuoteCharCode = textBox_QuoteCharCode.Text;
        }


        private bool ASCIIonly
        {
            get { return _CurrentCSVReader.ASCIIonly; }
            set
            {
                try
                {
                    if (_CurrentCSVReader.ASCIIonly != value)
                        _CurrentCSVReader.ASCIIonly = value;
                }
                finally
                {
                    checkBox_ASCIIonly.Checked = ASCIIonly;
                }
            }
        }// ASCIIonly

        private void checkBox_ASCIIonly_CheckedChanged(object sender, EventArgs e)
        {
            ASCIIonly = checkBox_ASCIIonly.Checked;
        }


        private void ShowStatus()
        {
            if (_CurrentCSVReader.Active)
            {
                labelReaderState.BackColor = System.Drawing.Color.Red;
                labelReaderState.ForeColor = System.Drawing.Color.White;
                labelReaderState.Text = "Active";
            }
            else
            {
                labelReaderState.BackColor = System.Drawing.Color.Lime;
                labelReaderState.ForeColor = System.Drawing.Color.Black;
                labelReaderState.Text = "Inactive";
            }
        }

        private string UInt16ToHex0x4DigitString(UInt16 aIntValue)
        {
            return "0x" + aIntValue.ToString("X4");
        }

        private int Hex0x4DigitMaxStringToUInt(string aStrValue)
        {
            return Convert.ToUInt16(aStrValue, 16);
        }

        private void SetDefaultInputProperties()
        {
            CSVStringReader tmpReader = new CSVStringReader();
            FieldCount_AutoDetect = tmpReader.FieldCount_AutoDetect;
            FieldCount = tmpReader.FieldCount.ToString();
            HeaderPresent = tmpReader.HeaderPresent;
            UseFieldDblQuoting = tmpReader.UseFieldQuoting;
            IgnoreEmptyLines = tmpReader.IgnoreEmptyLines;
            IgnoreSpecialCharacters = tmpReader.IgnoreSpecialCharacters;
            FieldSeparatorCharCode = UInt16ToHex0x4DigitString((UInt16)tmpReader.FieldSeparatorCharCode);
            QuoteCharCode = UInt16ToHex0x4DigitString((UInt16)tmpReader.QuoteCharCode);
            ASCIIonly = tmpReader.ASCIIonly;
        }

        private void buttonSetIputDefaults_Click(object sender, EventArgs e)
        {
            SetDefaultInputProperties();
        }

        private void SetCommonInputProperties(CSVReader aCSVReader)
        {
            aCSVReader.FieldCount_AutoDetect = FieldCount_AutoDetect;
            if (FieldCount_AutoDetect)
                aCSVReader.FieldCount = 0;
            else
                aCSVReader.FieldCount = Convert.ToInt32(FieldCount);
            aCSVReader.HeaderPresent = HeaderPresent;
            aCSVReader.IgnoreEmptyLines = IgnoreEmptyLines;
            aCSVReader.UseFieldQuoting = UseFieldDblQuoting;
            aCSVReader.IgnoreSpecialCharacters = IgnoreSpecialCharacters;
            aCSVReader.FieldSeparatorCharCode = Hex0x4DigitMaxStringToUInt(FieldSeparatorCharCode);
            aCSVReader.QuoteCharCode = Hex0x4DigitMaxStringToUInt(QuoteCharCode);
            aCSVReader.ASCIIonly = ASCIIonly;
        }

        
        private void DoReadFromFile()
        {
            CSVFileReader newCSVReader;
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.InitialDirectory = _InitialDirectory;
            openFileDialog.RestoreDirectory = true;
            openFileDialog.DefaultExt = "";
            openFileDialog.Filter = "";
            openFileDialog.Multiselect = false;
            openFileDialog.CheckPathExists = true;
            openFileDialog.CheckFileExists = true;

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                _InitialDirectory = Path.GetDirectoryName(openFileDialog.FileName);
                newCSVReader = new CSVFileReader();
                newCSVReader.FileName = openFileDialog.FileName;

                ReadCSVData(newCSVReader);
            }
        
        }

        private void buttonReadFromFile_Click(object sender, EventArgs e)
        {
            DoReadFromFile();
        }


        private void DoReadFromString()
        {
            CSVStringReader newCSVReader;
            newCSVReader = new CSVStringReader();
            newCSVReader.DataString = textBoxCSVString.Text;

            ReadCSVData(newCSVReader);
        }

        private void buttonReadFromString_Click(object sender, EventArgs e)
        {
            DoReadFromString();
        }

        
        private void CloseCSVReader()
        {
            try
            {
                _CurrentCSVReader.Close();
            }
            finally
            {
                ShowStatus();
            }
        }

        private void buttonClose_Click(object sender, EventArgs e)
        {
            CloseCSVReader();
        }


        private void ReadCSVData(CSVReader aCSVReader)
        {
            bool originalCursor = Application.UseWaitCursor;
            Application.UseWaitCursor = true;
            try
            {
                SetCommonInputProperties(aCSVReader); //copy property values from current reader

                CloseCSVReader(); // previous one

                _CurrentCSVReader = aCSVReader;

                Application.UseWaitCursor = true;

                ClearGrid();
                Application.DoEvents();

                _CurrentCSVReader.Open(); // new one

                FillGrid();
            }
            finally
            {
                Application.UseWaitCursor = originalCursor;
                ShowStatus();
            }
        }

        private void FillGrid()
        {
            ClearGrid();
            SetGridColumnNames();
            ReadDataIntoGrid();
        }


        private void ClearGrid()
        {
            _DataTable.Rows.Clear();
            _DataTable.Columns.Clear();
        }

        private void buttonClearGrid_Click(object sender, EventArgs e)
        {
            ClearGrid();
        }

        private void SetGridColumnNames()
        {
            string columnName;
            for (int i = 0; i <= _CurrentCSVReader.FieldCount-1; i++)
            {
                if (_CurrentCSVReader.HeaderPresent)
                    columnName = _CurrentCSVReader.Fields[i].Name;
                else
                    columnName = (i+1).ToString();
                _DataTable.Columns.Add(columnName);
            }
        }

        private void ReadDataIntoGrid()
        {
            int i = 0;
            while (! _CurrentCSVReader.Eof)
            {
                var row = _DataTable.NewRow();
                for (int j = 0; j <= _CurrentCSVReader.FieldCount - 1; j++)
                    row[j] = _CurrentCSVReader.Fields[j].Value;
                _DataTable.Rows.Add(row);

                dataGridView1.Rows[i].HeaderCell.Value = (i+1).ToString();
                i++;

                _CurrentCSVReader.Next();
            }// while (! Eof)

            dataGridView1.AutoResizeRowHeadersWidth(DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders);
        }// ReadDataIntoGrid()

        public Form1()
        {
            InitializeComponent();

            _DataTable = new DataTable();
            dataGridView1.DataSource = _DataTable;
            dataGridView1.AllowUserToAddRows = false;
            dataGridView1.AllowUserToDeleteRows = false;
            dataGridView1.AllowUserToOrderColumns = false;
            dataGridView1.ReadOnly = true;

            // create initial instance
            _CurrentCSVReader = new CSVStringReader();

            SetDefaultInputProperties();
            ShowStatus();
            _InitialDirectory = "";
        }



    }
}
