﻿namespace CSVReaderTest_WinForms
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.checkBox_ASCIIonly = new System.Windows.Forms.CheckBox();
            this.textBox_QuoteCharCode = new System.Windows.Forms.TextBox();
            this.checkBox_HeaderPresent = new System.Windows.Forms.CheckBox();
            this.textBox_FieldSeparatorCharCode = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.buttonSetIputDefaults = new System.Windows.Forms.Button();
            this.checkBox_IgnoreSpecialCharacters = new System.Windows.Forms.CheckBox();
            this.checkBox_UseFieldDblQuoting = new System.Windows.Forms.CheckBox();
            this.checkBox_IgnoreEmptyLines = new System.Windows.Forms.CheckBox();
            this.labelFieldCountCaption = new System.Windows.Forms.Label();
            this.textBox_FieldCount = new System.Windows.Forms.TextBox();
            this.checkBox_FieldCount_AutoDetect = new System.Windows.Forms.CheckBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.buttonReadFromFile = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.buttonReadFromString = new System.Windows.Forms.Button();
            this.textBoxCSVString = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.buttonClose = new System.Windows.Forms.Button();
            this.labelReaderState = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.buttonClearGrid = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.checkBox_ASCIIonly);
            this.panel1.Controls.Add(this.textBox_QuoteCharCode);
            this.panel1.Controls.Add(this.checkBox_HeaderPresent);
            this.panel1.Controls.Add(this.textBox_FieldSeparatorCharCode);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.buttonSetIputDefaults);
            this.panel1.Controls.Add(this.checkBox_IgnoreSpecialCharacters);
            this.panel1.Controls.Add(this.checkBox_UseFieldDblQuoting);
            this.panel1.Controls.Add(this.checkBox_IgnoreEmptyLines);
            this.panel1.Controls.Add(this.labelFieldCountCaption);
            this.panel1.Controls.Add(this.textBox_FieldCount);
            this.panel1.Controls.Add(this.checkBox_FieldCount_AutoDetect);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(12, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(181, 331);
            this.panel1.TabIndex = 0;
            // 
            // checkBox_ASCIIonly
            // 
            this.checkBox_ASCIIonly.AutoSize = true;
            this.checkBox_ASCIIonly.Location = new System.Drawing.Point(22, 247);
            this.checkBox_ASCIIonly.Name = "checkBox_ASCIIonly";
            this.checkBox_ASCIIonly.Size = new System.Drawing.Size(72, 17);
            this.checkBox_ASCIIonly.TabIndex = 13;
            this.checkBox_ASCIIonly.Text = "ASCIIonly";
            this.checkBox_ASCIIonly.UseVisualStyleBackColor = true;
            this.checkBox_ASCIIonly.CheckedChanged += new System.EventHandler(this.checkBox_ASCIIonly_CheckedChanged);
            // 
            // textBox_QuoteCharCode
            // 
            this.textBox_QuoteCharCode.Location = new System.Drawing.Point(24, 193);
            this.textBox_QuoteCharCode.Name = "textBox_QuoteCharCode";
            this.textBox_QuoteCharCode.Size = new System.Drawing.Size(100, 20);
            this.textBox_QuoteCharCode.TabIndex = 12;
            this.textBox_QuoteCharCode.Leave += new System.EventHandler(this.textBox_QuoteCharCode_Leave);
            // 
            // checkBox_HeaderPresent
            // 
            this.checkBox_HeaderPresent.AutoSize = true;
            this.checkBox_HeaderPresent.Location = new System.Drawing.Point(22, 31);
            this.checkBox_HeaderPresent.Name = "checkBox_HeaderPresent";
            this.checkBox_HeaderPresent.Size = new System.Drawing.Size(97, 17);
            this.checkBox_HeaderPresent.TabIndex = 4;
            this.checkBox_HeaderPresent.Text = "HeaderPresent";
            this.checkBox_HeaderPresent.UseVisualStyleBackColor = true;
            this.checkBox_HeaderPresent.CheckedChanged += new System.EventHandler(this.checkBox_HeaderPresent_CheckedChanged);
            // 
            // textBox_FieldSeparatorCharCode
            // 
            this.textBox_FieldSeparatorCharCode.Location = new System.Drawing.Point(22, 129);
            this.textBox_FieldSeparatorCharCode.Name = "textBox_FieldSeparatorCharCode";
            this.textBox_FieldSeparatorCharCode.Size = new System.Drawing.Size(100, 20);
            this.textBox_FieldSeparatorCharCode.TabIndex = 10;
            this.textBox_FieldSeparatorCharCode.Leave += new System.EventHandler(this.textBox_FieldSeparatorCharCode_Leave);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(19, 114);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(150, 13);
            this.label7.TabIndex = 9;
            this.label7.Text = "FieldSeparatorCharCode (Hex)";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(21, 177);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(111, 13);
            this.label8.TabIndex = 11;
            this.label8.Text = "QuoteCharCode (Hex)";
            // 
            // buttonSetIputDefaults
            // 
            this.buttonSetIputDefaults.Location = new System.Drawing.Point(57, 298);
            this.buttonSetIputDefaults.Name = "buttonSetIputDefaults";
            this.buttonSetIputDefaults.Size = new System.Drawing.Size(75, 23);
            this.buttonSetIputDefaults.TabIndex = 8;
            this.buttonSetIputDefaults.Text = "Set Defaults";
            this.buttonSetIputDefaults.UseVisualStyleBackColor = true;
            this.buttonSetIputDefaults.Click += new System.EventHandler(this.buttonSetIputDefaults_Click);
            // 
            // checkBox_IgnoreSpecialCharacters
            // 
            this.checkBox_IgnoreSpecialCharacters.AutoSize = true;
            this.checkBox_IgnoreSpecialCharacters.Location = new System.Drawing.Point(22, 270);
            this.checkBox_IgnoreSpecialCharacters.Name = "checkBox_IgnoreSpecialCharacters";
            this.checkBox_IgnoreSpecialCharacters.Size = new System.Drawing.Size(142, 17);
            this.checkBox_IgnoreSpecialCharacters.TabIndex = 7;
            this.checkBox_IgnoreSpecialCharacters.Text = "IgnoreSpecialCharacters";
            this.checkBox_IgnoreSpecialCharacters.UseVisualStyleBackColor = true;
            this.checkBox_IgnoreSpecialCharacters.CheckedChanged += new System.EventHandler(this.checkBox_IgnoreSpecialCharacters_CheckedChanged);
            // 
            // checkBox_UseFieldDblQuoting
            // 
            this.checkBox_UseFieldDblQuoting.AutoSize = true;
            this.checkBox_UseFieldDblQuoting.Location = new System.Drawing.Point(22, 159);
            this.checkBox_UseFieldDblQuoting.Name = "checkBox_UseFieldDblQuoting";
            this.checkBox_UseFieldDblQuoting.Size = new System.Drawing.Size(104, 17);
            this.checkBox_UseFieldDblQuoting.TabIndex = 5;
            this.checkBox_UseFieldDblQuoting.Text = "UseFieldQuoting";
            this.checkBox_UseFieldDblQuoting.UseVisualStyleBackColor = true;
            this.checkBox_UseFieldDblQuoting.CheckedChanged += new System.EventHandler(this.checkBox_UseFieldDblQuoting_CheckedChanged);
            // 
            // checkBox_IgnoreEmptyLines
            // 
            this.checkBox_IgnoreEmptyLines.AutoSize = true;
            this.checkBox_IgnoreEmptyLines.Location = new System.Drawing.Point(22, 225);
            this.checkBox_IgnoreEmptyLines.Name = "checkBox_IgnoreEmptyLines";
            this.checkBox_IgnoreEmptyLines.Size = new System.Drawing.Size(110, 17);
            this.checkBox_IgnoreEmptyLines.TabIndex = 6;
            this.checkBox_IgnoreEmptyLines.Text = "IgnoreEmptyLines";
            this.checkBox_IgnoreEmptyLines.UseVisualStyleBackColor = true;
            this.checkBox_IgnoreEmptyLines.CheckedChanged += new System.EventHandler(this.checkBox_IgnoreEmptyLines_CheckedChanged);
            // 
            // labelFieldCountCaption
            // 
            this.labelFieldCountCaption.AutoSize = true;
            this.labelFieldCountCaption.Location = new System.Drawing.Point(19, 75);
            this.labelFieldCountCaption.Name = "labelFieldCountCaption";
            this.labelFieldCountCaption.Size = new System.Drawing.Size(57, 13);
            this.labelFieldCountCaption.TabIndex = 3;
            this.labelFieldCountCaption.Text = "FieldCount";
            // 
            // textBox_FieldCount
            // 
            this.textBox_FieldCount.Location = new System.Drawing.Point(22, 90);
            this.textBox_FieldCount.Name = "textBox_FieldCount";
            this.textBox_FieldCount.Size = new System.Drawing.Size(100, 20);
            this.textBox_FieldCount.TabIndex = 2;
            this.textBox_FieldCount.Leave += new System.EventHandler(this.textBox_FieldCount_Leave);
            // 
            // checkBox_FieldCount_AutoDetect
            // 
            this.checkBox_FieldCount_AutoDetect.AutoSize = true;
            this.checkBox_FieldCount_AutoDetect.Location = new System.Drawing.Point(22, 56);
            this.checkBox_FieldCount_AutoDetect.Name = "checkBox_FieldCount_AutoDetect";
            this.checkBox_FieldCount_AutoDetect.Size = new System.Drawing.Size(136, 17);
            this.checkBox_FieldCount_AutoDetect.TabIndex = 1;
            this.checkBox_FieldCount_AutoDetect.Text = "FieldCount_AutoDetect";
            this.checkBox_FieldCount_AutoDetect.UseVisualStyleBackColor = true;
            this.checkBox_FieldCount_AutoDetect.CheckedChanged += new System.EventHandler(this.checkBox_FieldCount_AutoDetect_CheckedChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(25, 5);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(132, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "Input Parameters";
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.buttonReadFromFile);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Location = new System.Drawing.Point(199, 12);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(186, 331);
            this.panel2.TabIndex = 3;
            // 
            // buttonReadFromFile
            // 
            this.buttonReadFromFile.Location = new System.Drawing.Point(49, 146);
            this.buttonReadFromFile.Name = "buttonReadFromFile";
            this.buttonReadFromFile.Size = new System.Drawing.Size(89, 23);
            this.buttonReadFromFile.TabIndex = 1;
            this.buttonReadFromFile.Text = "Select && Open";
            this.buttonReadFromFile.UseVisualStyleBackColor = true;
            this.buttonReadFromFile.Click += new System.EventHandler(this.buttonReadFromFile_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(38, 5);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(110, 17);
            this.label2.TabIndex = 0;
            this.label2.Text = "Read from file";
            // 
            // panel3
            // 
            this.panel3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.buttonReadFromString);
            this.panel3.Controls.Add(this.textBoxCSVString);
            this.panel3.Controls.Add(this.label4);
            this.panel3.Controls.Add(this.label3);
            this.panel3.Location = new System.Drawing.Point(391, 12);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(379, 331);
            this.panel3.TabIndex = 4;
            // 
            // buttonReadFromString
            // 
            this.buttonReadFromString.Location = new System.Drawing.Point(144, 298);
            this.buttonReadFromString.Name = "buttonReadFromString";
            this.buttonReadFromString.Size = new System.Drawing.Size(75, 23);
            this.buttonReadFromString.TabIndex = 3;
            this.buttonReadFromString.Text = "Open";
            this.buttonReadFromString.UseVisualStyleBackColor = true;
            this.buttonReadFromString.Click += new System.EventHandler(this.buttonReadFromString_Click);
            // 
            // textBoxCSVString
            // 
            this.textBoxCSVString.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxCSVString.Location = new System.Drawing.Point(10, 43);
            this.textBoxCSVString.Multiline = true;
            this.textBoxCSVString.Name = "textBoxCSVString";
            this.textBoxCSVString.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textBoxCSVString.Size = new System.Drawing.Size(357, 247);
            this.textBoxCSVString.TabIndex = 2;
            this.textBoxCSVString.WordWrap = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(102, 24);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(162, 13);
            this.label4.TabIndex = 1;
            this.label4.Text = "(paste CSV string into below box)";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(122, 5);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(129, 17);
            this.label3.TabIndex = 0;
            this.label3.Text = "Read from string";
            // 
            // panel4
            // 
            this.panel4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel4.Controls.Add(this.buttonClose);
            this.panel4.Controls.Add(this.labelReaderState);
            this.panel4.Controls.Add(this.label5);
            this.panel4.Location = new System.Drawing.Point(12, 348);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(758, 34);
            this.panel4.TabIndex = 5;
            // 
            // buttonClose
            // 
            this.buttonClose.Location = new System.Drawing.Point(196, 5);
            this.buttonClose.Name = "buttonClose";
            this.buttonClose.Size = new System.Drawing.Size(75, 23);
            this.buttonClose.TabIndex = 2;
            this.buttonClose.Text = "Close";
            this.buttonClose.UseVisualStyleBackColor = true;
            this.buttonClose.Click += new System.EventHandler(this.buttonClose_Click);
            // 
            // labelReaderState
            // 
            this.labelReaderState.AutoSize = true;
            this.labelReaderState.BackColor = System.Drawing.SystemColors.Control;
            this.labelReaderState.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelReaderState.ForeColor = System.Drawing.SystemColors.ControlText;
            this.labelReaderState.Location = new System.Drawing.Point(124, 8);
            this.labelReaderState.Name = "labelReaderState";
            this.labelReaderState.Size = new System.Drawing.Size(64, 17);
            this.labelReaderState.TabIndex = 1;
            this.labelReaderState.Text = "Inactive";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(19, 10);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(99, 13);
            this.label5.TabIndex = 0;
            this.label5.Text = "CSVReader Status:";
            // 
            // panel5
            // 
            this.panel5.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel5.Controls.Add(this.buttonClearGrid);
            this.panel5.Controls.Add(this.label6);
            this.panel5.Controls.Add(this.dataGridView1);
            this.panel5.Location = new System.Drawing.Point(12, 387);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(758, 344);
            this.panel5.TabIndex = 6;
            // 
            // buttonClearGrid
            // 
            this.buttonClearGrid.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonClearGrid.Location = new System.Drawing.Point(671, 2);
            this.buttonClearGrid.Name = "buttonClearGrid";
            this.buttonClearGrid.Size = new System.Drawing.Size(75, 22);
            this.buttonClearGrid.TabIndex = 4;
            this.buttonClearGrid.Text = "Clear";
            this.buttonClearGrid.UseVisualStyleBackColor = true;
            this.buttonClearGrid.Click += new System.EventHandler(this.buttonClearGrid_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(13, 5);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(107, 13);
            this.label6.TabIndex = 1;
            this.label6.Text = "CSV Source content:";
            // 
            // dataGridView1
            // 
            this.dataGridView1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(10, 26);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(736, 306);
            this.dataGridView1.TabIndex = 0;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(782, 741);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.MinimumSize = new System.Drawing.Size(790, 700);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Nvv.Components.CSV.CSVReader test";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label labelFieldCountCaption;
        private System.Windows.Forms.TextBox textBox_FieldCount;
        private System.Windows.Forms.CheckBox checkBox_FieldCount_AutoDetect;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.CheckBox checkBox_IgnoreSpecialCharacters;
        private System.Windows.Forms.CheckBox checkBox_UseFieldDblQuoting;
        private System.Windows.Forms.CheckBox checkBox_IgnoreEmptyLines;
        private System.Windows.Forms.CheckBox checkBox_HeaderPresent;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button buttonReadFromFile;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button buttonReadFromString;
        private System.Windows.Forms.TextBox textBoxCSVString;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button buttonClose;
        private System.Windows.Forms.Label labelReaderState;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Button buttonSetIputDefaults;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button buttonClearGrid;
        private System.Windows.Forms.TextBox textBox_FieldSeparatorCharCode;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBox_QuoteCharCode;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.CheckBox checkBox_ASCIIonly;


    }
}

