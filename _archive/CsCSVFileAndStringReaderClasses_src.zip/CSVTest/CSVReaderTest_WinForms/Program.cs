﻿/*****************************************************/
/***    Copyright (c) 2014 Vladimir Nikitenko      ***/
/***      Code Project Open License (CPOL)         ***/
/*** (http://www.codeproject.com/info/cpol10.aspx) ***/
/*****************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace CSVReaderTest_WinForms
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            Application.ThreadException += Application_MainThreadException; //highest level exception handler

            Application.Run(new Form1());
        }

        static void Application_MainThreadException
    	    (object sender, System.Threading.ThreadExceptionEventArgs e)
        {// All exceptions thrown by the main thread are handled over this method

            MessageBox.Show(e.Exception.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

    }
}
