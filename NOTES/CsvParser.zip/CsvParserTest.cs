﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;

namespace Ideafixxxer.CsvParser.Test
{
    /// <summary>
    ///This is a test class for CsvParserTest and is intended
    ///to contain all CsvParserTest Unit Tests
    ///</summary>
    [TestClass()]
    public class CsvParserTest
    {
        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        // 
        //You can use the following additional attributes as you write your tests:
        //
        //Use ClassInitialize to run code before running the first test in the class
        //[ClassInitialize()]
        //public static void MyClassInitialize(TestContext testContext)
        //{
        //}
        //
        //Use ClassCleanup to run code after all tests in a class have run
        //[ClassCleanup()]
        //public static void MyClassCleanup()
        //{
        //}
        //
        //Use TestInitialize to run code before running each test
        //[TestInitialize()]
        //public void MyTestInitialize()
        //{
        //}
        //
        //Use TestCleanup to run code after each test has run
        //[TestCleanup()]
        //public void MyTestCleanup()
        //{
        //}
        //
        #endregion

        [TestMethod()]
        public void EmptyTest()
        {
            string[][] actual = Parse("");
            Assert.AreEqual(0, actual.Length); 
        }

        [TestMethod()]
        public void EmptyLineTest()
        {
            string[][] actual = Parse("\r\n");
            Assert.AreEqual(1, actual.Length);
            Assert.AreEqual(0, actual[0].Length); 
        }

        [TestMethod()]
        public void SingleCommaTest()
        {
            string[][] actual = Parse(",");
            Assert.AreEqual(1, actual.Length);
            AreEqual(new[] {"",""}, actual[0]); 
        }

        [TestMethod()]
        public void QuoteCharTest()
        {
            string[][] actual = Parse("a\"b");
            Assert.AreEqual(1, actual.Length);
            AreEqual(new[] {"a\"b"}, actual[0]); 
        }

        [TestMethod()]
        public void QuoteCharTest2()
        {
            string[][] actual = Parse("a\"");
            Assert.AreEqual(1, actual.Length);
            AreEqual(new[] {"a\""}, actual[0]); 
        }

        [TestMethod()]
        public void QuoteCharTest3()
        {
            string[][] actual = Parse("a\",b");
            Assert.AreEqual(1, actual.Length);
            AreEqual(new[] {"a\"", "b"}, actual[0]); 
        }

        [TestMethod()]
        public void SingleLineTest()
        {
            string[][] actual = Parse("a,b,c");
            Assert.AreEqual(1, actual.Length);
            AreEqual(new[] {"a", "b", "c"}, actual[0]);
        }

        [TestMethod()]
        public void SingleLineTest2()
        {
            string[][] actual = Parse("a,b,c\r\n");
            Assert.AreEqual(1, actual.Length);
            AreEqual(new[] {"a", "b", "c"}, actual[0]);
        }

        [TestMethod()]
        public void TwoLinesTest()
        {
            string[][] actual = Parse("a,b\r\nc,d");
            Assert.AreEqual(2, actual.Length);
            AreEqual(new[] {"a", "b"}, actual[0]);
            AreEqual(new[] {"c", "d"}, actual[1]);
        }

        [TestMethod()]
        public void QuotedValueTest()
        {
            string[][] actual = Parse("a,\"b\",c");
            Assert.AreEqual(1, actual.Length);
            AreEqual(new[] {"a", "b", "c"}, actual[0]);
        }

        [TestMethod()]
        public void SingleQuotedValueTest()
        {
            string[][] actual = Parse("\"b\"");
            Assert.AreEqual(1, actual.Length);
            AreEqual(new[] {"b"}, actual[0]);
        }

        [TestMethod()]
        public void EmptyQuotedValueTest()
        {
            string[][] actual = Parse("a,\"\",c");
            Assert.AreEqual(1, actual.Length);
            AreEqual(new[] { "a", "", "c" }, actual[0]);
        }

        [TestMethod()]
        public void EmptyValueTest()
        {
            string[][] actual = Parse("a,,c");
            Assert.AreEqual(1, actual.Length);
            AreEqual(new[] { "a", "", "c" }, actual[0]);
        }

        [TestMethod()]
        public void QuotedValueWithCommaTest()
        {
            string[][] actual = Parse("a,\"b,c\",d");
            Assert.AreEqual(1, actual.Length);
            AreEqual(new[] {"a","b,c", "d"}, actual[0]);
        }

        [TestMethod()]
        public void QuotedValueWithQuoteTest()
        {
            string[][] actual = Parse("a,\"b\"\"c\",d");
            Assert.AreEqual(1, actual.Length);
            AreEqual(new[] {"a","b\"c", "d"}, actual[0]);
        }

        [TestMethod()]
        public void QuotedValueWithEOLTest()
        {
            string[][] actual = Parse("a,\"b\r\nc\",d");
            Assert.AreEqual(1, actual.Length);
            AreEqual(new[] {"a","b\nc", "d"}, actual[0]);
        }

        [TestMethod()]
        public void EmptyLinesTest()
        {
            string[][] actual = Parse("a,b,c\r\n,,");
            Assert.AreEqual(2, actual.Length);
            AreEqual(new[] {"a", "b", "c"}, actual[0]);
            AreEqual(new[] {"", "", ""}, actual[1]);
        }

        private void AreEqual(string[] one, string[] two)
        {
            Assert.AreEqual(one.Length, two.Length);
            for (int i = 0; i < one.Length; i++)
            {
                Assert.AreEqual(one[i], two[i]);
            }
        }

        private string[][] Parse(string input)
        {
            CsvParser parser = new CsvParser();

            using (StringReader reader = new StringReader(input))
            {
                return parser.Parse(reader);
            }
        }
    }
}
